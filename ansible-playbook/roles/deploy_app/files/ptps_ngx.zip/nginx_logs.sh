#!/bin/bash
logs_path=/home/ptd/app/rg/logs
yesterDay=$(date -d "yesterday" +%Y%m%d)
#access
if [ -f ${logs_path}/access.log ]; then
   mv ${logs_path}/access.log ${logs_path}/access_${yesterDay}.log
fi
#error
if [ -f ${logs_path}/error.log ]; then
   mv ${logs_path}/error.log ${logs_path}/error_${yesterDay}.log
fi
#nginx
if [ -f ${logs_path}/nginx.log ]; then
   mv ${logs_path}/nginx.log ${logs_path}/nginx${yesterDay}.log
fi
kill -USR1 $(cat /home/ptd/app/rg/sbin/nginx.pid)
